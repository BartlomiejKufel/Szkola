const pole = (promien)=>{
    return 3.14*promien*promien
}

const obwod = (promien)=>{
    return 2*3.14*promien
}

const autor = "Bartłomiej Kufel"

module.exports = {
    pole:pole,
    obwod:obwod,
    autor: autor
}